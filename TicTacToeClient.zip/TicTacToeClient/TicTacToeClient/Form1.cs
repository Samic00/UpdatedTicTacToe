﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeClient
{
    public partial class Form1 : Form
    {
        char[] xo = new char[2];
        int a = 0;
        public Form1()
        {
            InitializeComponent();
            xo[0] = 'X';
            xo[1] = 'O';
        }
        string provjeraC;
        bool pr = false;
        bool KorisnikPridruzen = false;
        Int32 port;
        void Connect(String server,String message)
        {
            try
            {
                TcpClient client = new TcpClient(server, port);
                if (KorisnikPridruzen == false)
                {
                    message=message+"a1md";
                }
                Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

                NetworkStream stream = client.GetStream();
                stream.Write(data, 0, data.Length);
                provjeraC = "Connected";
                pr = true;
                System.Diagnostics.Debug.WriteLine("Sent: {0}", message);
                data = new Byte[256];
                String responseData = String.Empty;
                Int32 bytes = stream.Read(data, 0, data.Length);
                responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
                if (responseData.Contains("amdsawa1"))
                {
                    label5.Text = responseData.Substring(0, responseData.IndexOf("amdsawa1"));
                }
                System.Diagnostics.Debug.WriteLine("Received: {0}", responseData);
                
                if (responseData == label5.Text)
                {
                    unfreeze();
                }
                else
                {
                    freeze();
                }
                
                // Close everything.
                stream.Close();
                client.Close();
            }
            catch
            {
                provjeraC = "Not Connected";
                pr = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (KorisnikPridruzen == false)
                {
                    port = Int32.Parse(textBox3.Text);
                    Connect(textBox1.Text, textBox2.Text);
                    if (pr == true)
                    {
                        KorisnikPridruzen = true;
                        textBox1.Enabled = false;
                        textBox2.Enabled = false;
                        textBox3.Enabled = false;
                        button11.Enabled = true;
                    }
                }
                else
                {

                }

            }
            catch
            {

            }
            label1.Text = provjeraC;
        }
        void freeze()
        {
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
        }
        void unfreeze()
        {
            if (button2.Text == "")
            {
                button2.Enabled = true;
            }
            if (button3.Text == "")
            {
                button3.Enabled = true;
            }
            if (button4.Text == "")
            {
                button4.Enabled = true;
            }
            if (button5.Text == "")
            {
                button5.Enabled = true;
            }
            if (button6.Text == "")
            {
                button6.Enabled = true;
            }
            if (button7.Text == "")
            {
                button7.Enabled = true;
            }
            if (button8.Text == "")
            {
                button8.Enabled = true;
            }
            if (button9.Text == "")
            {
                button9.Enabled = true;
            }
            if (button10.Text == "")
            {
                button10.Enabled = true;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button2.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a%2]+"1");
            a++;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            button3.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "2");
            a++;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "3");
            a++;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.Enabled = false;
            button5.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "4");
            a++;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button6.Enabled = false;
            button6.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "5");
            a++;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.Enabled = false;
            button7.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "6");
            a++;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.Enabled = false;
            button8.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "7");
            a++;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.Enabled = false;
            button9.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "8");
            a++;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button10.Enabled = false;
            button10.Text = xo[a % 2].ToString();
            Connect(textBox1.Text, xo[a % 2] + "9");
            a++;
        }
        void ConnectReady()
        {
            try
            {

                string server = textBox1.Text;
                TcpClient client = new TcpClient(server, port);
                NetworkStream stream = client.GetStream();
                Byte[] data = new Byte[256];
                String responseData = String.Empty;
                Int32 bytes = stream.Read(data, 0, data.Length);
                responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);

                if (responseData == label5.Text)
                {
                    unfreeze();
                }
                stream.Close();
                client.Close();
            }
            catch
            {

            }
        }
        bool ready = false;
        private void button11_Click(object sender, EventArgs e)
        {
            if (ready == false)
            {
                ready = true;
                label6.Text="Ready";
                ConnectReady();
            }
            else
            {
                ;
            }
        }
    }
}
