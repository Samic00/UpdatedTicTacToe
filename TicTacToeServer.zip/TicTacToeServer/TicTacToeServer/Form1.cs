﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool GameStarted = false;

        int j = 0;
        int idIgraca = 0;
        TcpListener server = null;
        private void serverStarter()
        {
            try
            {
                // Set the TcpListener on port 13000.
                Int32 port = 13000;
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");

                // TcpListener server = new TcpListener(port);
                server = new TcpListener(localAddr, port);

                // Start listening for client requests.
                server.Start();

                // Buffer for reading data
                Byte[] bytes = new Byte[256];
                String data = null;

                // Enter the listening loop.
                while (true)
                {
                    System.Diagnostics.Debug.Write("Waiting for a connection... ");

                    // Perform a blocking call to accept requests.
                    // You could also use server.AcceptSocket() here.
                    TcpClient client = server.AcceptTcpClient();
                    System.Diagnostics.Debug.WriteLine("Connected!");

                    // Get a stream object for reading and writing
                    NetworkStream stream = client.GetStream();

                    int i;
                    // Loop to receive all the data sent by the client.
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        // Translate data bytes to a ASCII string.
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                        System.Diagnostics.Debug.WriteLine(data);
                        // Process the data sent by the client.
                        if (data.Contains("a1md"))
                        {
                            data = data.Substring(0,data.Length-4);
                            data = data + " id=" + j.ToString();
                            this.Invoke((MethodInvoker)(() => listBox1.Items.Add(data)));
                            data = "id=" + j.ToString() + "amdsawa1";
                            j++;
                        }
                        else if (data.Contains("NasdasReady"))
                        {
                            this.Invoke((MethodInvoker)(() => listBox2.Items.Add(data.Substring(0, data.IndexOf("NasdasReady")) + " is Ready")));
                        }
                        else
                        {
                            this.Invoke((MethodInvoker)(() => listBox2.Items.Add(data)));
                        }
                        
                        if (GameStarted==true)
                        {
                            byte[] msg1 = System.Text.Encoding.ASCII.GetBytes("id=0");
                            stream.Write(msg1, 0, msg1.Length);
                        }
                        else
                        {
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(data);

                            // Send back a response.
                            stream.Write(msg, 0, msg.Length);
                            System.Diagnostics.Debug.WriteLine("Sent: {0}", data);
                            data = null;
                        }
                        
                    }

                    client.Close();
                }
            }
            catch
            {

            }
        }
        Thread tr;
        bool st = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if (st == false)
            {
                tr = new Thread(serverStarter);
                tr.Start();
                label1.Text = "Server Started";
                st = true;
            }
            else
            {
                ;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (st == true)
            {
                server.Stop();
                label1.Text = "Server Stopped";
                st = false;
                GameStarted = false;
                j = 0;
                listBox1.Items.Clear();
                listBox2.Items.Clear();
            }
            else
            {

            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (st == true&&GameStarted==false)
            {
                GameStarted = true;
                this.Invoke((MethodInvoker)(() => listBox2.Items.Add("Game has started")));
            }
        }
    }
}
